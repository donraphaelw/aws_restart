myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))


